public class test16220
{
    public static  void main(String args[]) 
    {
        B sub = new B(); // 从字类B创建B对象
        System.out.println("i of B is: " + sub.i); // 答案是10
        System.out.println("i of B's super is: " + sub.geti()); // 调用父类的i;
        sub.addi(); // 变成了11
        System.out.println("i of B is: " + sub.i);
        System.out.println("i of B's super is: " + sub.geti());
    }
}

class A {
    int i=100;
    public void addi() {
        i++;
    }
}

class B extends A {
    int i=10;
    public void minusi() {
        i--;
    }
    public int geti() {
        return super.i;
    }
}
