public class test36220 {
    public static void main(String args[])
    {
        Cuboid c1 = new Cuboid(12,12,14);
        c1.cal();
        c1.printInfo();

        Cuboid c2 = new goods(5, 6, 7);
        c2.cal();
        c2.printInfo();
    }
    
}


class Cuboid
{
    int x;
    int y;
    int z;
    int v;

    Cuboid(int _x,int _y,int _z)
    {
        x = _x;
        y = _y;
        z = _z;
    }

    void cal()
    {
        v = x * y * z;
    }

    void printInfo()
    {
        System.out.println("长方体的长为 " + x + "长方体的宽为 " + y + "长方体的高为 " + z);
    }
}


class goods extends Cuboid
{
    int weight;
    int s;

    goods(int _x, int _y, int _z) {
        super(_x, _y, _z);
        System.out.println("商品类以被构造");
    }
    
    void cal()
    {
        s = 2 * (x + y + z);
        System.out.println(" 商品的表面积 " + s);
    }

    void printInfo()
    {
        System.out.println(" 商品的长为 " + x + " 商品的宽为 " + y + " 商品的高为 " + z + " 重量为 " + weight);
    }
}