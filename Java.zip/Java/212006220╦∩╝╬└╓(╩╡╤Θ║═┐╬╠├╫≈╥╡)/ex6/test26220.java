public class test26220 {
    public static void main(String args[])
    {
        vehiele v1 = new biycle();
        v1.run(10);
        v1.stop();

        vehiele v2 = new biycle(10,20);
        v2.run(20);
        v2.stop();

        vehiele v3 = new motorcar();
        v3.run(50);
        v3.stop();

        vehiele v4 = new motorcar(100,50);
        v4.run(20);
        v4.stop();
    }
    
}

class vehiele
{
    int v0; // 初速度
    int dv; //加速度
    int v; //当前速度
    int t; // 当前行驶的时间
    int s; // 当前行驶的路程

    vehiele()
    {
        v0 = 0;
        dv = 0;
        v = 0;
        s = 0;
        t = 0;
    }

    vehiele(int _v0,int _dv)
    {
        v0 = _v0;
        dv =_dv;
        t = 0;
        v = v0;
        s = 0;
    }

    void run(int _t)
    {
        t = _t;
        v = v0 + dv * t;
        s = (int)(v0 * t + 1.0 * 2 * dv * t * t);
    }

    void stop()
    {
        v0 = 0;
        v = 0;
        dv = 0;
    }
}

class biycle extends vehiele
{
    biycle()
    {
        super();
        System.out.println("自行车类的无参构造函数被调用");
    }

    biycle(int _v0,int _dv)
    {
        super(_v0,_dv);
        System.out.println("自行车类的有参构造函数被调用");
    }

    void run(int _t)
    {
        super.run(10);
        System.out.println("自行车运行了10秒后,当前速度为 " + v + "  当前的行驶距离为 " + s);
    }

    void stop()
    {
        super.stop();
        System.out.println("自行车停止,当前速度为 " + v);
    }
}

class motorcar extends vehiele
{
    motorcar()
    {
        super();
        System.out.println("汽车类的无参构造函数被调用");
    }


    motorcar(int _v0,int _dv)
    {
        super(_v0,_dv);
        System.out.println("汽车类的有参构造函数被调用");
    }
    
    void run(int _t)
    {
        super.run(30);
        System.out.println("汽车运行了30秒后,当前速度为 " + v + "  当前的行驶距离为 " + s);
    }

    void stop()
    {
        super.stop();
        System.out.println("汽车停止,当前速度为 " + v);
    }

}