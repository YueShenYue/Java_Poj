import java.util.*;

public class test6 {
    public static void main(String args[])
    {
        Scanner reader = new Scanner(System.in);
        String[] arr = new String[25];
        String str;
        for(int i = 0; i < 20; i++)
        {
            str = reader.next();
            int j = 0;
            for(; j < i; j++)
            {
                if(arr[j].equals(str))
                {
                    System.out.println("该学生重名  " + str);
                    break;
                }
            }
            if(j == i) arr[i] = str;
        }

        reader.close();
    }
}
