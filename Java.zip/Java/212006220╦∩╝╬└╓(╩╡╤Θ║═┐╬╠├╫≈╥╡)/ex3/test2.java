public class test2 {
    public static void main(String[] args) {
        int nowYear = 2017;
        int nowMonth = 10;
        if (args.length>0)
            nowYear = Integer.parseInt(args[0]);
        if (args.length>1)
            nowMonth = Integer.parseInt(args[1]);
        
        System.out.println(nowYear + "年" + nowMonth + "月有"
                + run(nowYear,nowMonth) + "天");
    }

    //计算本月是第几天
    
    public static int run(int year, int month) {
        int days = -1;
        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                days = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                days = 30;
                break;
            case 2:
                if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
                    days = 29;
                else
                    days = 28;
        }
        return days;
    }
}
