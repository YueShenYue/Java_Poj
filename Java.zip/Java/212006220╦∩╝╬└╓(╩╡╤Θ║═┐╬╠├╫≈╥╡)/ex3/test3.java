public class test3 {
    public static void mian(String args[])
    {
        System.out.println("输出以下数：");
        for (int i=100; i<1000; i++) {
            int a,b,c;
            a = i / 100;
            b = i / 10 % 10;
            c = i % 10;
            if (a*a*a+b*b*b+c*c*c==i)
                System.out.println(i);
        }
    }
}
//水仙花数
