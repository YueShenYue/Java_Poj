class Dog{
    String name;
    String color;
    double weight;
    int age;

    Dog(String _name,String _color,double _weight,int _age)
    {
        name = _name;
        color = _color;
        weight = _weight;
        age = _age;
    }

    void call()
    {
        System.out.println(name + " Call");
    }

    void bite()
    {
        System.out.println(name + " bite");
    }
}


public class test2 {
    public static void main(String[] args)
    {
        Dog a = new Dog("A","red",23.3,5);
        Dog b = new Dog("B","blue",15.3,2);

        a.call();
        b.bite();
    }
}
