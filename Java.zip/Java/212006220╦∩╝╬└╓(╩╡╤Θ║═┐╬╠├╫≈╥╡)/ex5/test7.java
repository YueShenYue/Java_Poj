class Book1{
    private String Isbn;
    private String name;
    private double price;
    
    Book1(String _isbn,String _name,double _price)
    {
        Isbn = _isbn;
        name = _name;
        price = _price;
    }
    
    void setIsbn(String isbn) {
        this.Isbn = isbn;
    }

    void setName(String name) {
        this.name = name;
    }

    void setPrice(double price) {
        this.price = price;
    }

    void display()
    {
        System.out.println(Isbn + "  " + name + "  " + price);
    }
}

public class test7 {
    /* 题目没要求写 */
}

