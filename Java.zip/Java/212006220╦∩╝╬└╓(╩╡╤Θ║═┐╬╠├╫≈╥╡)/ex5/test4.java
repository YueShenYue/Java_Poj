public class test4 {
    public static void main(String[] args)
    {
      Trangle a = new Trangle(1,4,5);
      a.getInfo();
      
      System.out.println(a.getS());
     System.out.println(a.getC());
      
    }
}

class Trangle
{
  double a;
  double b;
  double c;
  
  int is_valid()
  {
    if(a + b > c && a + c > b && b + c > a) return 1;
    return 0;
  }
  
  public Trangle(double _a,double _b,double _c)
  {
    a = _a;
    b = _b;
    c = _c;
  }
  
  public double getC()
  {
    int tmp = is_valid();
    if(tmp == 1)
      return a + b + c;
    else return -1;
  }
  
  public double getS()
  {
    int tmp = is_valid();
    if(tmp == 1)
    {
      double p = (a + b + c) / 2.0;
      double ans = Math.sqrt(p * (p - a) * (p - b) * (p - c));
      return ans;
    }
    else
    {
      System.out.println("is not valid");
      return -1;
    }
  }
  
  public void getInfo()
  {
     System.out.println(a + "  " + b + "  " + c);
  }
}
