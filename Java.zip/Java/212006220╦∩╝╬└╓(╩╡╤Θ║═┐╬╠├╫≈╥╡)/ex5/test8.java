class Book2{
    static private int all_num;
    static private double all_price;

    private String Isbn;
    private String name;
    private double price;
    private int num;
    
    Book2(String _isbn,String _name,double _price,int _num)
    {
        Isbn = _isbn;
        name = _name;
        price = _price;
        num = _num;
        
        all_num += _num;
        all_price += _num * _price;
    }
    
    void setIsbn(String isbn) {
        this.Isbn = isbn;
    }

    void setName(String name) {
        this.name = name;
    }

    void setNum(int num)
    {
        all_num -= this.num;
        this.num = num;
        all_num += num;
    }

    void display()
    {
        System.out.println(Isbn + "  " + name + "  " + price + "  " + num);
    }

    static void  get_all_num()
    {
        System.out.println(all_num);
    }

    static void get_all_price()
    {
        System.out.println(all_price);
    }
}

public class test8 {
    public static void main(String[] args)
    {
        Book2 a = new Book2("1234", "ABC", 23.4, 4);

        a.display();
        
        Book2.get_all_num();
        Book2.get_all_price();

    }
}

