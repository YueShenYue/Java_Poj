class Student{
    private static int count; // 对外界隐藏数据
    private String no;
    private String name;
    private int age;

    Student(String _no,String _name,int _age)
    {
        no = _no;
        name = _name;
        age = _age;
        count++;
    }

    void init(String _no,String _name,int _age)
    {
        no = _no;
        name = _name;
        age = _age;
    }

    void modify(String _no,String _name,int _age)
    {
        no = _no;
        name = _name;
        age = _age;
    }

    static int get_num()
    {
        return count;
    }

    void printInfo()
    {
        System.out.println(no + "  " + name + "  " + age);
    }
}

public class test5 {
    public static void main(String[] args)
    {
        Student a = new Student("212006220","sunjiale",1);
        Student b = new Student("212006221","wanyongkang",2);

        a.printInfo();
        b.printInfo();

        a.modify("212006220","SJL",3);
        a.printInfo();
    }
}
