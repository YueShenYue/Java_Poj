public class test3 {
    public static void main(String[] args)
    {
      Employee a = new Employee("wang","gulou","fuzhou","fujian","362200");
      a.getInfo();
    }
}

class Employee{
  String name;
  String street;
  String city;
  String province;
  String postcode;
  
  public Employee(String _name,String _street,String _city,String _province,String _postcode)
  {
    name = _name;
    street = _street;
    city = _city;
    province = _province;
    postcode = _postcode;
  }
  
  public void modify(String _name,String _street,String _city,String _province,String _postcode)
  {
    name = _name;
    street = _street;
    city = _city;
    province = _province;
    postcode = _postcode;
  }
  
  public void getInfo()
  {
    System.out.println(name + "  " + street + "  " + city  + "  "+ province);
  }
}
