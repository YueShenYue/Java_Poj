class Rect {
    private double w,h;
    Rect(double w, double h) {
        this.w = w;
        this.h = h;
    }
    Rect (Rect s) {
        w = s.w;
        h = s.h;
    }
    double getw() {
        return w;
    }
    double geth() {
        return h;
    }
    double area() {
        return getw() * geth();
    }
}
public class test9 {
    public static void run() {
        Rect s[] = new Rect[3];
        s[0] = new Rect(2,3);
        s[1] = new Rect(5,6);
        s[2] = new Rect(new Rect(7,8));
        for (int i=0; i<s.length; i++) {
            System.out.println("s[" + i + "] area=" + s[i].area());
        }
    }

    public static void main(String[] args)
    {
        run();
    }

    //两个构造函数, 一个直接赋值. 一个是传入对象. 也就是复制构造函数.
}
