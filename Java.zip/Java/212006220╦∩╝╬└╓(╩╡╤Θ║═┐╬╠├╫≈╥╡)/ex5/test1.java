class Num {
    int x,y,z,sum;
    Num(int i, int j, int k) {
        x = i;
        y = j;
        z = k;
        sum = x + y + z;
    } // 初始化构造函数

    boolean isSameNum(Num a) {
        if (a.x==x && a.y==y && a.z==z)
            return true;
        else
            return false;
    } //判单两个类的数据是否相同.

    boolean isSameSum(Num b) {
        if (b.sum==sum)
            return true;
        else
            return false;
    }
}

public class test1 {
    public static  void run() 
    {
        Num a = new Num(3,6,9);
        Num b = new Num(3,6,9);
        Num c = new Num(6,9,3);
        System.out.println(a.isSameNum(b));
        System.out.println(b.isSameNum(c));
        System.out.println(a.isSameSum(b));
        System.out.println(b.isSameSum(c));
    }

    public static void main(String[] args)
    {
        run();
    }
    
}
