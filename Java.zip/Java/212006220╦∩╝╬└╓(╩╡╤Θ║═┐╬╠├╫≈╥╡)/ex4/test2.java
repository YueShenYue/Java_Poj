import java.util.*;

public class test2 {
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String[][] arr = new String[3][4];
        String str;
        int cnt = 0;
        for(int i = 0; i < 3; i++)
            for(int j = 0; j < 4; j++)
            {
                str = sc.next();
                arr[i][j] = str;
                if(str.equals("Good"))
                {
                    System.out.println(i + "  " + j);
                    cnt++;
                }
            }
        if(cnt == 0)    System.out.println("未找到");
        sc.close();
    }
}
