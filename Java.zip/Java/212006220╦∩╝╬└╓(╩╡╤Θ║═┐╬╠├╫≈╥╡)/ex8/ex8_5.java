/*
 * 5．（附加题）编写一个类实现银行帐户的概念，包括的属性有“帐号”、“储户姓名”、“存款余额”，
 * 包括的方法有“存款”、“取款”、“查询”以及构造方法等。创建“取款数目超过余额”这个异常，
 * 并在取款方法中抛出这个异常。在测试类中能处理该异常。
 */

 class Account{
     String id;
     String name;
     double money;
     
     Account(){}
     Account(String _id,String _name,double _money)
     {
         this.id = _id;
         this.name= _name;
         this.money = _money;
     }

    void Deposit(double m){
        this.money += m;
    }
  
    void Pickup(double m) throws NumberOutRangeException {
        if(this.money < m) throw new  NumberOutRangeException ("取款数超过了存款数");
        this.money -= m;
    }

    void Query()
    {
        System.out.println("当前用户id " + this.id + " 当前用户姓名 " + this.name + " 当前存款是 : " + this.money);
    }
 }

 class NumberOutRangeException extends Exception{
    public NumberOutRangeException(String msg){
        super(msg);
    }
}

class AccountTest{
    public static void main(String args[])
    {
        Account ac = new Account("212006220","孙嘉乐",200);
        ac.Query();

        ac.Deposit(350);
        ac.Query();

        try{
            ac.Pickup(10);
            ac.Query();
            ac.Pickup(200000);
            ac.Query();
        }
        catch(NumberOutRangeException e){
            e.printStackTrace();
        }
    }
}