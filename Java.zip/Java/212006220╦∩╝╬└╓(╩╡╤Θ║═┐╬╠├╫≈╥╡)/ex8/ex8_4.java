/*
 * 4. (选做题)编写自定义异常程序，输入一个字符，若为小写字母（97-122）直接输出该字母，
 * 并输出“这是一个小写字母”；若是大写字母（65-90）直接输出该字母，并输出“这是一个大写字母”
 * 若不为字母，则抛出异常InvalidCharException。
其中InvalidCharException为自定义的异常类 。
当程序出现异常，应当进行捕获处理。
 */

import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStreamReader; 

class InvalidCharException extends Exception{
    public InvalidCharException(String msg){
        super(msg);
    }
}


class alphabetTest {
    public static void main(String args[]) throws IOException{
        System.out.println("请输入字母 : ");
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        char ch = (char) br.read();
        try{
            print(ch);
           } 
        catch (InvalidCharException e) 
        { 
            e.printStackTrace();
        }
    }
    public static void print(char ch) throws InvalidCharException
    {		
        if(ch >= 'a' && ch <= 'z')
        {
            System.out.println(ch + " 这是一个小写字母");
        }
        else if(ch >= 'A' && ch <= 'Z')
        {
            System.out.println(ch + " 这是一个大写字母");
        }
        else 
        {
            throw new InvalidCharException("不是字母");
        }
    }
 }
