import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
 class CIRCLE {
	public static void main(String[] args) throws IOException {
		System.out.print("请输入半径: "); 
	    BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
	    try{
	        System.out.println("圆的面积为："+computerArea(Double.parseDouble(br.readLine())));
			}
		catch(NumberFormatException e){
				System.out.println("您输入的不是数值，请重新输入");
			}
		}
        
    public static double computerArea(double r)
    {
    	return Math.PI*r*r;
}
}

