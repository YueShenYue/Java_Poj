abstract class Geometry
{
   abstract double getArea();
}

class Pillar{
    Geometry bottom;
    double height;
    Pillar(Geometry g1,double h)
    {
        bottom = g1;
        height = h;
    }

    public double getVolume()
    {
        return bottom.getArea() * height;
    }
}

class Circle extends Geometry{
    double radius;

    Circle()
    {
        radius = 1;
        System.out.println("默认半径为 1");
    }
    double getArea()
    {
        return 3.1415926 * radius * radius;
    }
}

class Retanglg extends Geometry{
    double a,b;
    Retanglg()
    {
        a = 2;
        b = 3;
        System.out.println("默认长宽为2,3");
    }

    double getArea()
    {
        return a * b;
    }
}


public class pillarTest{
    public static void main(String args[])
    {
        Geometry bottom  = new Retanglg();
        Pillar pillar = new Pillar(bottom, 58);
        
        System.out.println(pillar.getVolume());

        bottom = new Circle();
        pillar = new Pillar(bottom,58);
        System.out.println(pillar.getVolume());
    }
}