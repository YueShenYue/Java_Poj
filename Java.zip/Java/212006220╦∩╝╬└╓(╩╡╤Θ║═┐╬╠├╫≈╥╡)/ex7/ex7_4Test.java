interface Biology
{
    void breath();
}

interface Animal extends Biology
{
    void move();
    void eat();
}

interface Mankind extends Animal{
    void study();
    void think();

}

class NormalMan implements Animal
{
    String name;
    NormalMan()
    {
        name = "NUll";
    }
    
    NormalMan(String _name)
    {
        name = _name;
    }

    public void breath()
    {
        System.out.println("人类呼吸");
    }

    
    public void move()
    {
        System.out.println("人类移动");
    }
    
    public void eat()
    {
        System.out.println("人类吃食物");
    }

    public void study()
    {
        System.out.println("人类学习");
    }
    
    public void think()
    {
        System.out.println("人类思考");
    }
}

public class ex7_4Test {
    public static void main(String args[])
    {
        NormalMan a = new NormalMan("sunjiale");
        a.breath();
    }


}



