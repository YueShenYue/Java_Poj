
abstract class Cash{
    double amount;
    double interest;
    double tax;

    abstract double calculate();
}

class HalfCash extends Cash{

    HalfCash(double _num)
    {
        amount = _num;
        interest =0.0175;
        tax = 0.05; 
    }
    double calculate()
    {
        return amount * interest * (1 - tax);
    }
}


class FullCash extends Cash{

    FullCash(double _num)
    {
        amount = _num;
        interest =0.0225;
        tax = 0.05; 
    }
    double calculate()
    {
        return amount * interest * (1 - tax);
    }
}


public class ex7_2Test {
    public static void main(String args[])
    {
        HalfCash a = new HalfCash(1000);
        System.out.println(a.calculate());

        FullCash b = new FullCash(1000);
        System.out.println(b.calculate());
    }
}






/*
要求：
（1）设计一个存款抽象类Cash，成员变量包括存款金额amount、利息率interest和利息所得税tax（为最终类），成员方法只有抽象方法calculate()，用来计算利息；
（2）定义两个类HalfCash和FullCash，分别用来完成计算和显示定期存款半年和一年相应的利息；
（3）给出程序，当存款金额为1000元时，运行出其结果。
*/
