class Person6220{
    String name;
    int age;
    String id;
    Person6220()
    {
        name = "";
        age = 18;
        id = "";
        System.out.println("Person constructor1 ..");
    }

    Person6220(String name, int age,String id)
    {
        this.name = name;
        this.age = age;
        this.id = id;
        System.out.println("Person constructor2 ..");
    }

    void setInfo(String name,int age,String id)
    {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    void printInfo()
    {
        System.out.println("name" + name + " age" + age + " id" + id);
    }   
}

class Student6220 extends Person6220
{
    String Sno;
    Student6220()
    {
        super();
        Sno = "";
        System.out.println("Student constructor1 ..");
    }

    Student6220(String name,int age,String id,String Sno)
    {
        super();
        this.Sno = Sno;
        System.out.println("Student constructor2 ..");
    }

    void setInfo(String name,int age,String id,String sno)
    {
        super.setInfo(name, age, id);
        this.Sno = sno;
    }

    void printInfo()
    {
        super.printInfo();
        System.out.println(" Sno" + Sno);
    }   
}


class Test6220
{
    public static void main(String args[])
    {
        Student6220 s1 = new Student6220();
        s1.printInfo();
        s1.setInfo("sun", 20, "212006220","212006220");
        s1.printInfo();

        Student6220 s2 = new Student6220("sun", 20, "212006220","212006220");
        s2.printInfo();
    }
}