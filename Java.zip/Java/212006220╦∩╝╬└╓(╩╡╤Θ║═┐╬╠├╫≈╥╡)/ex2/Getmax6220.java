class Getmax {
    int a;
    int b;
    int c;
    double x;
    double y;
    double z;

    Getmax(int na,int nb){
        a = na;
        b = nb;
        System.out.println(Math.max(a,b));
    }

    Getmax(int na,int nb,int nc){
        a = na;
        b = nb;
        c = nc;
        System.out.println(Math.max(a,Math.max(b,c)));
    }

    Getmax(double xx,double yy)
    {
        x = xx;
        y = yy;
        System.out.println(Math.max(x,y));
    }

    Getmax(double xx,double yy,double zz)
    {
        x = xx;
        y = yy;
        z = zz;
        System.out.println(Math.max(x,Math.max(y,z)));
    }
    
}

public class Getmax6220{
    public static void main(String[] args)
    {
        Getmax a = new Getmax(4, 5);
        Getmax b = new Getmax(4.0, 5.0);
        Getmax c = new Getmax(4, 5,6);
        Getmax d = new Getmax(4.44, 5.55,6.66);
    }
}