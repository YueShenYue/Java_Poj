public class Employee6220 {
    public static void main(String[] args)
    {
        Employee a = new Employee("孙嘉乐", "鼓楼区", "福州", "鼓楼", "362200");
        a.show();
        
    }
}

class Employee{
    String name;
    String street;
    String city;
    String province;
    String postcode;    

    Employee(String nname,String nstreet,String ncity,String nprovince,String npostcode)
    {
        name = nname;
        street = nstreet;
        city = ncity;
        province = nprovince;
        postcode = npostcode;
    }

    void modify(String nname,String nstreet,String ncity,String nprovince,String npostcode)
    {
        name = nname;
        street = nstreet;
        city = ncity;
        province = nprovince;
        postcode = npostcode;
    }

    void show()
    {
        System.out.println(name + "  " + street + "   " + city + "   " + province + "   " + postcode);
    }
}