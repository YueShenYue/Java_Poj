public class Trape6220 {
    public static void main(String[] args)
    {
        Trape a = new Trape();
        Trape b = new Trape(2,4,6);
        Trape c = new Trape(10,15,12);
        System.out.println(a.getS());
        System.out.println(b.getS());
        System.out.println(c.getS());
        
    }

}

class Trape{
    double shangdi;
    double xiadi;
    double h;

    Trape()
    {
        shangdi = 0;
        xiadi = 0;
        h = 0;
    }

    Trape(double na,double nb,double nc)
    {
        shangdi = na;
        xiadi = nb;
        h = nc;
    }

    void modify(double na,double nb,double nc)
    {
        shangdi = na;
        xiadi = nb;
        h = nc;
    }


    double getS()
    {
        return (shangdi + xiadi) * h * 1.0 / 2;
    }

}