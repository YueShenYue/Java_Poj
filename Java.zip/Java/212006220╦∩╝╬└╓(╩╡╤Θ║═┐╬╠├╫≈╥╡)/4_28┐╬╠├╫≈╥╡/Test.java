class stu{
    String sno;
    String name;
    int grade;
    cla _class; // 班级

    stu()
    {
        sno = "000000";
        name = "NULL";
        grade = -1;
    }

    stu(String _sno,String _name,int _grade,cla __class)
    {
        sno = _sno;
        name = _name;
        grade = _grade;
        _class = __class;
    }

    void setInfo(String _sno,String _name,int _grade)
    {
        sno = _sno;
        name = _name;
        grade = _grade;
       

    }

    void printInfo()
    {
        System.out.println(sno + "  " + name + "  " + grade);
        _class.printInfo();
    }
}

class cla{
    String className;
    int num;
    String classMonitorName;

    cla()
    {
        className = "NULL";
        num = -1;
        classMonitorName = "NULL";
    }

    cla(String _className,int _num, String _classMonitorName)
    {
        className = _className;
        num = _num;
        classMonitorName = _classMonitorName;
    }

    void setInfo(String _className,int _num, String _classMonitorName)
    {
        className = _className;
        num = _num;
        classMonitorName = _classMonitorName;
    }
    
    void printInfo()
    {
        System.out.println(className + " have " + num + " MonitorName is" + classMonitorName);
    }
}


class Test{
    public static void main(String args[])
    {
        cla c = new cla("计科3班",10,"徐毅");
        stu a = new stu("212006220","孙嘉乐",1,c);

        a.printInfo(); // 输出自己的时候还会输出班级的信息.就不调用班级了
        
    }
}