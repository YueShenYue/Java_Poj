    import java.util.*;

    class Second {
        public static void main(String[] agrs)
        {
            Scanner read = new Scanner(System.in);
            System.out.println("查询的次数");
            int T = read.nextInt();       
            
            for(int i = 0; i < T; i++)
            {
                int m = read.nextInt();
                if(m == 1) System.out.println("一月份");
                else if(m == 2) System.out.println("二月份");
                else if(m == 3) System.out.println("三月份");
                else if(m == 4) System.out.println("四月份");
                else if(m == 5) System.out.println("五月份");
                else if(m == 6) System.out.println("六月份");
                else if(m == 7) System.out.println("七月份");
                else if(m == 8) System.out.println("八月份");
                else if(m == 9) System.out.println("九月份");
                else if(m == 10) System.out.println("十月份");
                else if(m == 11) System.out.println("十一月份");
                else System.out.println("十二月份");
            }
            read.close();
        }
    }
