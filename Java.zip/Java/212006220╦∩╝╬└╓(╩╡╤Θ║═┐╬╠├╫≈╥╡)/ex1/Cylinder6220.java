class Cylinder {
    double r;
    double h;
    double s;
    double c;
    double v;

    Cylinder()
    {
        r = 0;
        s = 0;
        c = 0;
        v=  0;
    }

    Cylinder(double nr,double nh)
    {
        r = nr;
        h = nh;
        s = Math.PI * r * r;
        c = Math.PI * 2 * r;
        v = Math.PI * r * r  * h;
    }
    
    double getS()
    {
        return s;
    }

    double getC()
    {
        return c;
    }
    double getV()
    {
        return v;
    }
}


public class Cylinder6220{
    public static void main(String[] args)
    {
        int[] x; 
        
    }
}