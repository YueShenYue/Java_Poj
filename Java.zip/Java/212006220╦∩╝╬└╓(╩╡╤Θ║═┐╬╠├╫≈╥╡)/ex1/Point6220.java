class Point {
    int x;
    int y;
    Point()
    {
        x = 0;
        y = 0;
    }
    Point(int a,int b)
    {
        x = a;
        y = b;
    }
    Point(int t)
    {
        x  = t;
        y = 0;
    }

    void show()
    {
        System.out.println(x + "  " + y);
    }


}

public class Point6220{
    public static void main(String[] args)
    {
        Point a = new Point();
        Point b = new Point(4,5);
        Point c = new Point(4);
        a.show();
        b.show();
        c.show();
    }
}