public class Student6220 {
    public static void main(String[] args)
    {
        Student a = new Student();
        a.show();
        Student b = new Student(212006220,"sunjiale",1);
        b.show();
    }
}

class Student{
    int no;
    String name;
    int age;
   Student()
    {
        no = -1;
        name = "NULL";
        age = -1;
    } 

    Student(int Sno,String Sname,int Sage)
    {
        no = Sno;
        name = Sname;
        age = Sage;
    } 

    void getInfo(int Sno,String Sname,int Sage)
    {
        no = Sno;
        name = Sname;
        age = Sage;
    }

    void modify(int Sno,String Sname,int Sage)
    {
        no = Sno;
        name = Sname;
        age = Sage;
    }

    void show()
    {
        System.out.println(no + "  " + name + "  " + age);
    }
}