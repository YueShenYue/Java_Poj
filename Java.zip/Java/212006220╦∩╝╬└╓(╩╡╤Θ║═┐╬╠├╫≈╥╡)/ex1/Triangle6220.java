public class Triangle6220 {
    public static void main(String[] args)
    {
        Triangle a = new Triangle();
        Triangle b = new Triangle(3,4,5);
        a.getC();
        a.getS();

        b.getC();
        b.getS();
        
        a.show();
        b.show();

        System.out.println(a.getC() + b.getC());
        System.out.println(a.getS() + b.getS());
    }
}

class Triangle{
    double a;
    double b;
    double c;

    Triangle(double na,double nb,double nc)
    {
        a = na;
        b = nb;
        c = nc;
    }

    Triangle()
    {
        a = b = c = -1;
    }

    int check()
    {
        if(a + b > c && b + c > a && a + c > b) return 1;
        return 0;
    }

    double getC()
    {
        if(check() == 1)
            return a + b + c;
        else return -1;
    }
    
    double getS()
    {
        if(check() == 1)
        {
            double p = (a + b + c) / 2;
            return Math.sqrt(p * (p - a) * (p - b) * (p -c));
        }
        else return -1;
    }

    void show()
    {
        System.out.println(a + "  " + b + "  " + c);
    }   
}