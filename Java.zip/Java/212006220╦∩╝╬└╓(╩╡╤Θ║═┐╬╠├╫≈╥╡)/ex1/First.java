import java.util.*;

public class First{
    public static void main(String[] args){
        Scanner read = new Scanner(System.in);
        int a = read.nextInt();
        int b = read.nextInt();

        System.out.println("长为 " + a);
        System.out.println("宽为 " + b);
        
        read.close();
    }
}