package ex3;

import java.util.*;

public class Test7 {
	public static void main(String args[]) {
		Scanner reader = new Scanner(System.in);
		int sum = 0;
		
		long st = System.currentTimeMillis();
		long ed = 0;
		
		for (int i = 0; i < 10; i++) {
			int t = reader.nextInt();
			sum += t;
		}

		
		System.out.println(1.0 * sum / 10);
		
		ed = System.currentTimeMillis();
		System.out.println(ed - st);
		
		reader.close();

	}
}
