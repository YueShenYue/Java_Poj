package ex1;

public class Student {
	String id;
	String name;
	String age;
	boolean isMale;

}
