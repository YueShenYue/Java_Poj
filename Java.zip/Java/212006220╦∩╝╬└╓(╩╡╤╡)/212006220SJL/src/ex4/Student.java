package ex4;

public class Student {
	String id;
	String name;
	boolean isMale;
	int mathScore;
	int englishScore;
	
	
	public Student(String id, String name, boolean isMale, int mathScore, int englishScore) {
		super();
		this.id = id;
		this.name = name;
		this.isMale = isMale;
		this.mathScore = mathScore;
		this.englishScore = englishScore;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isMale() {
		return isMale;
	}
	public void setMale(boolean isMale) {
		this.isMale = isMale;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	public int getEnglishScore() {
		return englishScore;
	}
	public void setEnglishScore(int englishScore) {
		this.englishScore = englishScore;
	}
	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", isMale=" + isMale + ", mathScore=" + mathScore
				+ ", englishScore=" + englishScore + "]";
	}
	
	
	public boolean cmp(Student b)
	{
		if(this.mathScore != b.mathScore) return this.mathScore > b.mathScore;
		return this.englishScore > b.englishScore;
	}
	
	
}


