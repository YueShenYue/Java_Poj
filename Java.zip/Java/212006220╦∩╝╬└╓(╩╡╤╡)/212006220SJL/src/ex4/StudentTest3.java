package ex4;

public class StudentTest3 {
	public static void main(String args[]) {
		Student[] stu = {
				new Student("212006220","�����",true,150,150),
				new Student("212006220","�����",true,15,10),
				new Student("212006220","�����",true,110,50),
				new Student("212006220","�����",true,140,110),
				new Student("212006220","�����",true,150,50),
				new Student("212006220","�����",true,19,8),
				new Student("212006220","�����",true,18,12)
		};
		
		Student tmp;
		
		for(int i = 0; i < stu.length; i++)
		{
			for(int j = 0; j < stu.length; j++)
			{
				if(!stu[j].cmp(stu[i]))
				{
					tmp = stu[i];
					stu[i] = stu[j];
					stu[j] = tmp;
				}
			}
		}
		
		for(int i = 0; i < stu.length; i++)
		{
			System.out.println(stu[i].toString());
		}
	}
}
