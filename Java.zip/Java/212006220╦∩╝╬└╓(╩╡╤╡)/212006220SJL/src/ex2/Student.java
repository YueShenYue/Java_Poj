package ex2;

public class Student {
	String id;
	String name;
	String age;
	boolean isMale;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public boolean isMale() {
		return isMale;
	}

	public void setMale(boolean isMale) {
		this.isMale = isMale;
	}

	public Student(String id, String name, String age, boolean isMale) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.isMale = isMale;
	}

	public Student() {
		super();
	}

}
