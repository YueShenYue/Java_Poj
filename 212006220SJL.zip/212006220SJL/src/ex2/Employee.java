package ex2;


/**
 * @author SJL
 *@version JDK1.8
 *
 */


/**
 * 
 * @param id ����֤����
 * @param name ����
 * @param age ����
 * @param isMale �Ƿ�Ϊ����,����Ϊtrue,����Ϊfalse
 * @param departMent �鿴���ڵĲ���
 * @param duty �鿴ְ��
 */

public class Employee extends People {
	String departMent;
	String duty;


	public String getDepartMent() {
		return departMent;
	}
	

	public void setDepartMent(String departMent) {
		this.departMent = departMent;
	}

	public String getDuty() {
		return duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}
	

	public Employee(String id, String name, int age, boolean isMale, String departMent, String duty) {
		super(id, name, age, isMale);
		this.departMent = departMent;
		this.duty = duty;
	}
	
	public Employee() {
		super();
		this.departMent = "null";
		this.duty = "null";
	}

}