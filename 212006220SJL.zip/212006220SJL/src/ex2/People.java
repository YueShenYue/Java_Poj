package ex2;

import java.util.Objects;

/**
 * 
 * @author SJL
 *@VERSION JDK1.8
 */

public class People {
	String id;
	String name;
	int age;
	boolean isMale;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isMale() {
		return isMale;
	}

	public void setMale(boolean isMale) {
		this.isMale = isMale;
	}
	
	/**
	 * 
	 * @param id ����֤��
	 * @param name ����
	 * @param age ����
	 * @param isMale �Ƿ�Ϊ����,����Ϊtrue,����Ϊfalse
	 */

	public People(String id, String name, int age, boolean isMale) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.isMale = isMale;
	}

	public People() {
		this.id = "null";
		this.name = "null";
		this.age = -1;
		this.isMale = true;
	}

	@Override
	public String toString() {
		return "People [id=" + id + ", name=" + name + ", age=" + age + ", isMale=" + isMale + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, id, isMale, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		People other = (People) obj;
		return age == other.age && Objects.equals(id, other.id) && isMale == other.isMale
				&& Objects.equals(name, other.name);
	}

	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}


