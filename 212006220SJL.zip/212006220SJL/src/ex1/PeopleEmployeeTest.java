package ex1;
import ex2.*;

public class PeopleEmployeeTest {
	public static void main(String args[])
	{
		People a = new People ("212006220","SJL",-1,true);
		System.out.println(a.getAge());
		System.out.println(a.getName());
		System.out.println(a.getId());
		
		
		Employee b = new Employee("212006220","Lihua",101,false,"temp","tmp");
		
		System.out.println(b.getAge());
		System.out.println(b.getName());
		System.out.println(b.getId());
		System.out.println(b.getDepartMent());
		System.out.println(b.getDuty());

	}
}
