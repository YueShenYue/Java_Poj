package ex1;

public class HelloWorld2 {
	public static void main(String args[]) {
		System.out.println(" ");
		System.out.println("My name is Wangtao.");
		System.out.println("I am ready.");	
		System.out.println("Here we go!");
	}
	
}
