package ex1;
import ex2.Student;

public class StudentTest {
	public static void main(String args[])
	{
		Student a = new Student("212006220","�����",10,true);
		System.out.println(a.getAge());
		System.out.println(a.getName());
		System.out.println(a.getId());
	}
}
