package ex4;

import java.util.*;

public class StudentTest2 {
	public static void main(String args[]) {
		Scanner reader = new Scanner(System.in);
		
		String name,id;
		boolean ismale;
		int math,eng;
		Student[] stu = new Student[20];
		
		for(int i = 0; i < 7; i++) {
			id = reader.next();
			name = reader.next();
			ismale = reader.nextBoolean();
			math = reader.nextInt();
			eng = reader.nextInt();
			stu[i] = new Student(id,name,ismale,math,eng);
		}
		
		for(int i = 0; i < 7; i++)
		{
			if(stu[i].englishScore >= 90 && stu[i].mathScore >= 90)
			{
				System.out.println(stu[i].toString());
			}
		}
	}
}
