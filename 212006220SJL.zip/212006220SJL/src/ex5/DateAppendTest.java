package ex5;

import java.util.*;

public class DateAppendTest {
	public static void main(String args[])
	{
		Calendar calendar = Calendar.getInstance();
		calendar. add (Calendar. DATE, 999);
		int year = calendar.get (Calendar. YEAR);
		int month = calendar.get (Calendar.MONTH);
		int date = calendar.get (Calendar.DATE);
		
		System.out.println(year + "  " + month + "  " + date);
	}
}