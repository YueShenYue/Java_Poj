package ex5;

import java.util.*;
import java.text.*;

public class DayOfTheWeekTest {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		try {
			Calendar c = stringToCalendar(str); 
			System.out.println(checkDate(c)); 
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		sc.close();
	}


	public static Calendar stringToCalendar(String str) throws ParseException
	{
		SimpleDateFormat df1 =  new SimpleDateFormat("yyyy-mm-dd");
		Date date = df1.parse(str);
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c;
	}
	
	public static String checkDate(Calendar c)
	{
		int m = c.get(Calendar.MONTH);
		int d = c.get(Calendar.DATE);
		return "������ " + m + " �� " + d + " ��";
	}
	
}
