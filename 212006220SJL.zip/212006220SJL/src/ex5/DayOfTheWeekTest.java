package ex5;

import java.util.*;
import java.text.*;

public class DayOfTheWeekTest {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String str = "2022-6-9";
		try {
			Calendar c = stringToCalendar(str); 
			checkDate(c); 
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		sc.close();
	}

	public static Calendar stringToCalendar(String str) throws ParseException
	{
		Date date=new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	    date = df.parse(str);
		Calendar c=Calendar.getInstance();
		c.setTime(date);
		return c;
	}
	
	public static void checkDate(Calendar c)
	{
		System.out.println("������������  " + (c.get(Calendar.DAY_OF_WEEK) - 1));
	}
	
}
