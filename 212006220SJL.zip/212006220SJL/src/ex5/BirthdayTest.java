package ex5;

import java.util.*;
import java.text.*;


public class BirthdayTest {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		try {
			Calendar c = stringToCalendar(str); // ����A, ���ܻ����ת���쳣
			System.out.println(getMonthAndDate(c)); // ����B
			System.out.println(getToday());  //����C
			checkBirthday(c);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		sc.close();
	}

	public static Calendar stringToCalendar(String str) throws ParseException
	{
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		
		Calendar c=Calendar.getInstance();
		c.setTime(date);
		return c;
	}
	
	public static String getMonthAndDate(Calendar c)
	{
		int m = c.get(Calendar.MONTH);
		int d = c.get(Calendar.DATE);
		return "��������� " + m + 1 + " �� " + d + " ��";
	}
	
	public static String getToday()
	{
		Calendar calendar = Calendar.getInstance();
		int m = calendar.get(Calendar.MONTH);
		int d = calendar.get(Calendar.DATE);
		return "������ " + m + " �� " + d + " ��";
	}
	
	public static void checkBirthday(Calendar c) // ��������
	{
		Calendar calendar = Calendar.getInstance();
		int m = calendar.get(Calendar.MONTH);
		int d = calendar.get(Calendar.DATE);
		if(m == c.get(Calendar.MONTH) && d == c.get(Calendar.DATE))
		{
			System.out.println("Hi! Today is your birthday. Happy birthday to you!");
		}
		else {
			System.out.println("Today is not your birthday.");
		}
	}
}
