package ex3;

import java.util.*;

public class Test6 {
	public static void main(String args[])
	{
		Scanner reader = new Scanner(System.in);
		String ans = "";
		for(int i = 0; i < 5; i++)
		{
			Integer tmp = reader.nextInt();
			ans += tmp.toString();
		}
		
		System.out.println(ans);
		reader.close();
		
	}
}
