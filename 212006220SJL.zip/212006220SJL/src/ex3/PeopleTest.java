package ex3;
import ex2.People;

public class PeopleTest {
	public static void main(String args[])
	{
		System.out.println("----");
		People a = new People("212006220","SJL",101,false);
		People c = new People("123","hh",-1,true);
		System.out.println(a.toString());
		System.out.println(a.equals(c));
		System.out.println("----");
		
		System.out.println("----");
		People b = a;
		System.out.println(b.toString());
		
		System.out.println(b.hashCode());
		System.out.println(b.getClass());
	}
}
