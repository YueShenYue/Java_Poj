package ex3;

import java.util.Scanner;

public class Test8 {
	public static void main(String args[])
	{
		Scanner reader =new Scanner(System.in);
		String str;

		long ed = 0;
		
		float sum = 0;
		
		str = reader.nextLine();
		String nums[] = str.split(",");

		long st = System.currentTimeMillis();
		
		for(int i = 0; i < nums.length; i++)
		{
			sum += Float.parseFloat(nums[i]);
		}
		
		System.out.println("sum = " + 1.0 * sum / 10);
		
		ed = System.currentTimeMillis();
		System.out.println("����ִ��ʱ��   " + (ed - st) + " ����");
		
		reader.close();
		
	}
}
