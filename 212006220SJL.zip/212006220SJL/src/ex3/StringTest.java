package ex3;
import java.util.Scanner;

public class StringTest {
	public static void main(String args[])
	{
		Scanner reader = new Scanner(System.in);
		String str = reader.nextLine();
		String[] arr = str.split(" ");
		int cnt = 0;
		System.out.println("���ʵ����� = " + arr.length);
		for(int i = 0; i < arr.length; i++)
			{
				System.out.println(arr[i]);
				if(arr[i].equals("good")) cnt++;
			}
		System.out.println("good�ĵ��ʵ�����" + cnt);
		reader.close();
	}
}
