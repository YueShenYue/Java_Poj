package ex3;

public class StringTest3 {
	public static void main(String args[]) {
		String str = new String("ABCDEFG");
		str = str.toLowerCase();
		char[] arr = str.toCharArray();
		arr[0] -= 32;
		
		for(int i = 0; i < arr.length; i++)
		{
			System.out.print(arr[i]);
		}
	}
}
