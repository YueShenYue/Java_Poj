package ex3;

import java.util.Scanner;

/*
 * ����trie��
 * ��ѯ"abb"���ִ���
 */

public class StringTest2 {
	static int N = 10010; 
	static int son[][] = new int[N][26];
	static int cnt[] = new int[N];
	static char str[] = new char[N];
	static int idx = 0;
	
	public static void main(String args[]) {
		Scanner reader = new Scanner(System.in);

		System.out.println("����һ�����ַ���,ÿ��������һ���ո����");
		String str = reader.nextLine();
		String substr[] = str.split(" ");
		
		for(int i = 0; i < substr.length; i++)
		{
			insert(substr[i].toCharArray());
		}
		
		String pat = "abb";
		
		System.out.println(query(pat.toCharArray()));
		
		reader.close();
		
	}
	
	static void insert(char[] str) {
		int p = 0;
		for(int i= 0; i < str.length; i++) {
			int u = str[i] - 'a';
			if(son[p][u] == 0) son[p][u] = ++idx;
			p = son[p][u];
		}
		cnt[p]++;
	}
	
	static int query(char[] str) {
		int p = 0;
		for(int i = 0; i < str.length; i++) {
			int u = str[i] - 'a';
			if(son[p][u] == 0) return 0;
			p = son[p][u];
		}
		
		return cnt[p];
	}
}
