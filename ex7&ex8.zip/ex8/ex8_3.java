import java.io.BufferedReader;
import java.io.IOException; 
import java.io.InputStreamReader; 
class SumTest {
		public static void main(String[] args) throws IOException
		{
			System.out.println("请输入两个正整数(回车分隔):");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			int a=Integer.parseInt(br.readLine());
			int b=Integer.parseInt(br.readLine());
			try{
				System.out.println("计算结果(求和)为：" +compute(a, b));
			   } 
			catch (NumberRangeException e) 
			{ 
				e.printStackTrace();
			}
		}
		public static int compute(int a, int b) throws NumberRangeException
		{		
			if( (a<0 || b<0))
			{
			    throw new NumberRangeException("数字不在指定范围");
			}
		    return (a+b);
		}
}

class NumberRangeException extends Exception {
      public NumberRangeException(String msg){
    	 super(msg);
      }
}
