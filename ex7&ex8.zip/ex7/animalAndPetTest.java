abstract class Animal{
    int legs;
    Animal(int _legs)
    {
        legs = _legs;
    }

    abstract void walk();
    abstract void eat();
}

interface Pet{
    String getName();
    void setName(String name);
    void play();
}

class Cat extends Animal implements Pet{
    String name;

    Cat(String _name)
    {
        super(4);
        name = _name;
    }

    Cat()
    {
        super(4);
        setName("NULL");
    }

    void walk(){
        System.out.println("猫走路");
    }

    void eat(){
        System.out.println("猫吃东西");
    }

    public void play()
    {
        System.out.println("猫玩耍");
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

class Spider extends Animal{
    Spider()
    {
        super(8);
    }

    void eat(){
        System.out.println("蜘蛛吃东西");
    }

    void walk(){
        System.out.println("蜘蛛走路");
    }
}


class Fish extends Animal implements Pet{
    String name;

    Fish()
    {
        super(1);

    }

    void walk(){
        System.out.println("鱼走路");
    }

    void eat(){
        System.out.println("鱼吃东西");
    }


    public void play()
    {
        System.out.println("鱼玩耍");
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

class animalAndPetTest{
    public static void main(String args[])
    {
        Cat a = new Cat("HelloKity");
        a.walk();
        a.eat();
        a.setName("Paofu");
        a.play();
        System.out.println(a.getName());

        Spider b = new Spider();
        b.walk();
        b.eat();
        

        Fish c = new Fish();
        c.walk();
        c.eat();
        c.play();
        c.setName("美人鱼战士");
        System.out.println(c.getName());
    }
}