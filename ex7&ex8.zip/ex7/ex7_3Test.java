
interface NextNumber {
    int getNext();
    void setReset(int x);
}

class NatureNum implements NextNumber {
    int i;
    NatureNum() {
        i = 0;
    } 
    public int getNext() {
        i++;
        return i;
    }
    public void setReset(int i) {
        this.i = i;
    }
}
class EvenNum implements NextNumber {
    int i;
    EvenNum() {
        i = 0;
    }
    public int getNext() {
        i = i + 2;
        return i;
    }
    public void setReset(int i) {
        this.i = i;
    }
}

public class ex7_3Test {
    public static void main(String args[]) 
     {
        NextNumber num = new NatureNum();
        for (int i=0;i<5;i++)
            System.out.print(num.getNext() + "  ");
        System.out.println(); // 每次取得一个数字

        num.setReset(10); // 重置到10
        for(int i=0;i<5;i++)
            System.out.print(num.getNext() + "  ");
        
        num = new EvenNum(); // 转换为一个偶数类
        for (int i=0;i<5;i++)
            System.out.print(num.getNext() + "  ");
        System.out.println();
    }
}
